import org.junit.Assert;
import org.junit.Test;

public class CodekataTest {
    /**
     * Here write tests of functions
     * */
    @Test
    public void test1(){
        Assert.assertEquals(CodekataProblem.myProblem(0), 0);
    }
}
