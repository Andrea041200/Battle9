public class CodekataProblem {
    /**
     * Here write functions to be implemented
     * */
    public static int myProblem(int i){
        return i;
    }
}
